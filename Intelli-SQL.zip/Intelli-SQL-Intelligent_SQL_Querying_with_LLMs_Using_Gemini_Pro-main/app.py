import sqlite3
from flask import Flask, request, jsonify

app = Flask(__name__)

# Simulated LLM logic (Rule-based for demo)
def generate_sql(user_query):
    user_query = user_query.lower()

    if "all users" in user_query:
        return "SELECT * FROM users;"
    elif "all products" in user_query:
        return "SELECT * FROM products;"
    elif "all orders" in user_query:
        return "SELECT * FROM orders;"
    else:
        return "SELECT * FROM users;"

@app.route("/query", methods=["POST"])
def query_database():
    user_query = request.json.get("query")

    sql_query = generate_sql(user_query)

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    try:
        cursor.execute(sql_query)
        results = cursor.fetchall()
        conn.close()

        return jsonify({
            "generated_sql": sql_query,
            "results": results
        })
    except Exception as e:
        conn.close()
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)
