\# IntelliSQL – Intelligent SQL Querying with LLMs Using Gemini



\## Project Overview

IntelliSQL is an AI-powered SQL query assistant that converts natural language questions into SQL queries using Google's Gemini API and executes them on a SQLite database.



This project demonstrates how Large Language Models (LLMs) can simplify database interactions for non-technical users.



---



\## Features

\- Convert natural language queries to SQL

\- Execute SQL queries on SQLite database

\- REST API built using Flask

\- JSON response containing:

&nbsp; - Generated SQL

&nbsp; - Query results



---



\## Tech Stack

\- Python 3.11

\- Flask

\- SQLite3

\- Google Gemini API

\- Git \& GitHub



---



\## Project Structure
IntelliSQL/

│── app.py

│── database\_setup.py

│── database.db

│── .env

│── screenshots/

│── README.md



---



\## Setup Instructions



\###  Clone the repository
git clone <your-repo-link>

cd IntelliSQL





\### Create virtual environment
python -m venv myenv

myenv\\Scripts\\activate





\###  Install dependencies

pip install flask google-generativeai python-dotenv





\### Add your Gemini API key

Create a `.env` file:



GOOGLE\_API\_KEY=your\_api\_key\_here (key should not spread everywhere)





\### Initialize database

python database\_setup.py





\### Run the application

python app.py





Server runs at:

&nbsp;http://127.0.0.1:5000





---



\### Example API Call



curl -X POST http://127.0.0.1:5000/query



-H "Content-Type: application/json"

-d "{"query":"Show all users"}"





---



\## Demo Screenshots

Screenshots are available inside the `/screenshots` folder.



---



\## Future Improvements

\- Add authentication

\- Add web frontend UI

\- Add support for multiple database types

\- Improve SQL validation \& security



---
## Demo Screenshots

### Server Running
![Server Running](screenshots/server-running.png)

### Empty Result
![Empty Result](screenshots/empty_result.png)

### Successful Query
![Successful Query](screenshots/query_success.png)




\## Author

Satya Upendra Samana







