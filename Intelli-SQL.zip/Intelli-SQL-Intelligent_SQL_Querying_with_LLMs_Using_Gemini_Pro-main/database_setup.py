import sqlite3

# Connect to database (this will create it if it doesn't exist)
conn = sqlite3.connect("database.db")
cursor = conn.cursor()

# Create Users table
cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    name TEXT,
    email TEXT
)
""")

# Create Products table
cursor.execute("""
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    name TEXT,
    price REAL
)
""")

# Create Orders table
cursor.execute("""
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY,
    user_id INTEGER,
    product_id INTEGER
)
""")
# Insert sample data
cursor.execute("INSERT INTO users (name, email) VALUES ('Shashi', 'shashi@email.com')")
cursor.execute("INSERT INTO users (name, email) VALUES ('Rahul', 'rahul@email.com')")

cursor.execute("INSERT INTO products (name, price) VALUES ('Laptop', 50000)")
cursor.execute("INSERT INTO products (name, price) VALUES ('Phone', 20000)")

cursor.execute("INSERT INTO orders (user_id, product_id) VALUES (1, 1)")
cursor.execute("INSERT INTO orders (user_id, product_id) VALUES (2, 2)")


conn.commit()
conn.close()

print("Database and tables created successfully!")
